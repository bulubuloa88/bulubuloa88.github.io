from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from json import loads
from xbmcvfs import translatePath
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/605.1.15 EdgA/134.0.0.0'
bl = 'https://bluphim.fun'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title=None, img=None, plot=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def main():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'timkiem')
    T = {'Thể loại': 'bluphim_tl',
        'Quốc gia': 'bluphim_qg'}
    dulieu = {
        'Phim mới': f'{bl}/the-loai/phim-moi-1',
        'Cập nhật': f'{bl}/the-loai/phim-cap-nhat-1',
        'Phim lẻ': f'{bl}/the-loai/phim-le-1',
        'Phim bộ': f'{bl}/the-loai/phim-bo-1',
        'Phim chiếu rạp': f'{bl}/the-loai/phim-chieu-rap-1',
        'Hoạt hình': f'{bl}/the-loai/hoat-hinh-1'
        }
    for b in T:
        addDir(b, ICON, b, T[b])
    for k in dulieu:
        addDir(k, ICON, k, 'ds_bluphim', url = dulieu[k])
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timblu', key = m)
    endOfDirectory(HANDLE)
def timkiem(query):
    sr = quote_plus(query)
    url = f'{bl}/search?k={sr}'
    danhsach(url)
def bluphim_tl():
    dulieu = {
        'Thần thoại - Cổ trang': f'{bl}/the-loai/than-thoai-co-trang-1',
        'Hành động': f'{bl}/the-loai/hanh-dong-1',
        'Tâm lý': f'{bl}/the-loai/tam-ly-1',
        'Chiến tranh': f'{bl}/the-loai/chien-tranh-1',
        'Võ thuật - Kiếm hiệp': f'{bl}/the-loai/vo-thuat-kiem-hiep-1',
        'Nhạc kịch': f'{bl}/the-loai/nhac-kich-1',
        'Kinh dị': f'{bl}/the-loai/kinh-di-1',
        'Tội phạm - Hình sự': f'{bl}/the-loai/toi-pham-hinh-su-1',
        'Phiêu lưu': f'{bl}/the-loai/phieu-luu-1',
        'Hài hước': f'{bl}/the-loai/hai-huoc-1',
        'Viễn tưởng': f'{bl}/the-loai/vien-tuong-1',
        'Khoa học - Tài liệu': f'{bl}/the-loai/khoa-hoc-tai-lieu-1',
        'Hoạt hình': f'{bl}/the-loai/hoat-hinh-1',
        'Thể thao': f'{bl}/the-loai/the-thao-1',
        'Tình cảm - Lãng mạn': f'{bl}/the-loai/tinh-cam-lang-man-1',
        'Kỳ ảo': f'{bl}/the-loai/ky-ao-1',
        'Giật gân': f'{bl}/the-loai/giat-gan-1',
        'Gia đình': f'{bl}/the-loai/gia-dinh-1',
        'Bí ẩn': f'{bl}/the-loai/bi-an-1',
        'Lịch sử': f'{bl}/the-loai/lich-su-1',
        'Viễn Tây': f'{bl}/the-loai/vien-tay-1',
        'Tiểu sử': f'{bl}/the-loai/tieu-su-1',
        'GameShow': f'{bl}/the-loai/chuong-trinh-truyen-hinh-1',
    }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_bluphim', url = dulieu[k])
    endOfDirectory(HANDLE)
def bluphim_qg():
    dulieu = {
        'Âu - Mỹ': f'{bl}/quoc-gia/au-my-1',
        'Trung Quốc - Hồng Kông': f'{bl}/quoc-gia/trung-quoc-hong-kong-1',
        'Hàn Quốc': f'{bl}/quoc-gia/han-quoc-1',
        'Nhật Bản': f'{bl}/quoc-gia/nhat-ban-1',
        'Ấn Độ': f'{bl}/quoc-gia/an-do-1',
        'Việt Nam': f'{bl}/quoc-gia/viet-nam-1',
        'Tổng hợp': f'{bl}/quoc-gia/tong-hop-1',
    }
    for k in dulieu:
        addDir(k, ICON, k, 'ds_bluphim', url = dulieu[k])
    endOfDirectory(HANDLE)
def danhsach(url):
    r = getlink(url, url, 1000)
    parse = r.parse()
    if 'list-films' in r.text:
        root = parse.iterfind('.//div[@class="list-films film-new"]//li[@class]')
        for k in root:
            tenphim = domhtml(k, './/a//div[@class="name"]//')
            linkphim = domhtml(k, './/a', attribute='href')
            anhphim = domhtml(k, './/img', attribute='src')
            anhphim = anhphim if anhphim.startswith('http') else f'{bl}{anhphim}'
            addDir(tenphim, anhphim, tenphim, 'info_bluphim', url = linkphim, img_film=anhphim, namefilm=tenphim)
    pages = parse.iterfind('.//div[@class="pagination"]//a')
    for a in pages:
        tentrang = a.text
        linktrang = a.get('href')
        addDir(tentrang, nextimg, tentrang, 'ds_bluphim', url = linktrang)
    endOfDirectory(HANDLE)
def play_bluphim(url):
    url = url if url.startswith('http') else f'{bl}{url}'
    resp = getlink(url, url, -1)
    u = resp.parse().find('.//iframe[@id="iframeStream"]').get('src')
    r = getlink(u, u, -1)
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'var videoId' in r.text:
        match = re.search(r"var videoId.*?['|\"](.*?)['|\"].*?var subId.*?['|\"](.*?)['|\"].*?var web.*?['|\"](.*?)['|\"].*?var cdn.*?['|\"](.*?)['|\"].*?var lang.*?['|\"](.*?)['|\"]", r.text, re.DOTALL)
        u2 = f'{referer(u)}geturl?renderer=ANGLE%20(Intel,%20Intel(R)%20HD%20Graphics%20Direct3D11%20vs_5_0%20ps_5_0)&id=79b42d6abdc359ebb2f740a0ecb67c7f&videoId={match[1]}&domain={bl}/'
        r2 = getlink(u2, u2, -1)
        streaming_url = f"{match[4]}/streaming?id={match[1]}&subId={match[2]}&web={match[3]}&{r2.text}&cdn={match[4]}&lang={match[5]}"
        r3 = getlink(streaming_url, u2, -1)
        a = re.search(r"var url.*?['|\"](.*?)['|\"].*?['|\"](.*?)['|\"]", r3.text)
        linkplay = f'{a[1]}{match[1]}{a[2]}'
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(streaming_url)}"
        if 'vietnam' in r3.text.lower():
            sub = ''.join((k['file'] for k in loads(re.search(r'tracks:.*?(\[.*?\]),', r3.text)[1]) if 'vietnam' in k['label'].lower()))
            play_item.setSubtitles([sub])
    else:
        u1 = re.search("embedIframe.*?=['|\"](.*?)['|\"]", r.text)[1]
        r2 = getlink(u1, u, -1)
        linkplay = re.search("var url.*?['|\"](.*?)['|\"]", r2.text)[1]
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(linkplay)}"
    linkplay = re.sub(r'\s+', '%20', linkplay.strip(), flags=re.UNICODE)
    play_item.setProperty('inputstream', 'inputstream.adaptive')
    play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
    play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def info_bluphim(url, img_film, namefilm):
    url = url if url.startswith('http') else f'{bl}{url}'
    r = getlink(url, url, 1000)
    uplay = domhtml(r.parse(), './/div[@class="info"]//li[@style]//a', attribute='href')
    plot = domhtml(r.parse(), './/div[@class="detail"]//div[@class="tab"]')
    urlplay = uplay if uplay.startswith('http') else f"{bl}{uplay}"
    resp = getlink(urlplay, url, 1000)
    if 'list-episode' in resp.text:
        s = resp.parse().iterfind('.//div[@class="control-box clear"]//div[@class="list-episode"]//a[@class]')
        for k in s:
            tentap = f'[COLOR yellow]{k.text}[/COLOR] {namefilm}'
            addDir(tentap, img_film, plot, 'play_bluphim', url = k.get('href'), is_folder=False)
    endOfDirectory(HANDLE)
def search():
    query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query)
    else:
        find()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'bluphim_tl': bluphim_tl,
        'bluphim_qg': bluphim_qg,
        'ds_bluphim': partial(danhsach, params.get('url')),
        'info_bluphim': partial(info_bluphim, params.get('url'), params.get('img_film'), params.get('namefilm')),
        'search': search,
        'timkiem': find,
        'timblu': partial(timkiem, params.get('key')),
        'play_bluphim': partial(play_bluphim, params.get('url')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass