# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os

from resources.libs.common import directory
from resources.libs.common.config import CONFIG


class MainMenu:

    def get_listing(self):
        from resources.libs import check
        from resources.libs.common import logging
        from resources.libs.common import tools

        errors = int(logging.error_checking(count=True))
        errorsfound = str(errors) + ' Error(s) Found' if errors > 0 else 'None Found'



 
        directory.add_dir('[B][COLOR yellow]SAO LƯU & KHÔI PHỤC[/COLOR][/B] ', {'mode': 'maint', 'name': 'backuprestore'}, icon=CONFIG.ICONMAKECUSTOM, themeit=CONFIG.THEME1)

        
  
        
        
        directory.add_dir('[COLOR yellow][B]GIAO DIỆN[/B][/COLOR] ', {'mode': 'builds'}, icon=CONFIG.ICONBUILDS, themeit=CONFIG.THEME1)
        directory.add_dir('[COLOR yellow][B]TIỆN ÍCH[/B][/COLOR]', {'mode': 'maint'}, icon=CONFIG.ICONULTILITIES, themeit=CONFIG.THEME1)
        directory.add_dir('[COLOR yellow][B]TỐI ƯU[/B][/COLOR]', {'mode': 'advanced_settings'}, icon=CONFIG.ICONADDVANCE, themeit=CONFIG.THEME3)
        directory.add_file('[B][COLOR yellow]CÀI ĐẶT[/COLOR][/B]', {'mode': 'settings', 'name': CONFIG.ADDON_ID}, icon=CONFIG.ICONSETTINGS, themeit=CONFIG.THEME1)

