from urllib.parse import urlencode, parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from urllib.parse import quote_plus
from xbmcaddon import Addon
from random import randint
from xbmcvfs import translatePath
from json import loads,dumps
from collections import OrderedDict
import sys, os, urlquick, re, xbmcgui, xbmc
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
addon_icon = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES + 'search.png'
hdvnimg = RESOURCES + 'hdvn.png'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'),'plugin.video.timfshare')
def get_url(**kwargs):
    return f'{addon_url}?{urlencode(kwargs)}'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(name, binary=False):
    content = None
    read_mode = 'rb' if binary else 'r'
    try:
        path = get_file_path(name)
        f = open(path, mode=read_mode)
        content = f.read()
        f.close()
    except:
        pass
    return content
def write_file(name, content, binary=False):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(name)
    try:
        write_mode = 'wb+' if binary else 'w+'
        f = open(path, mode=write_mode)
        f.write(content)
        f.close()
    except:
        pass
    return path
def get_last_search():
    content = read_file('search.json')
    content = loads(content) if content else {}
    return content
def save_last_search(data):
    if not data:
        return
    content = read_file('search.json')
    content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
    cache_id, query = data
    content.update({cache_id: query})
    content.move_to_end(cache_id, last=False)
    while len(content) > int(Addon().getSetting('numsearch')):
        content.popitem(last=True)
    write_file('search.json', dumps(content))
def addDir(title, img, detail, dir_url):
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(detail)
    list_item.setProperty('IsPlayable', 'false')
    info_tag.setMediaType('tvshow')
    addDirectoryItem(HANDLE, dir_url, list_item, True)
def get_tkfs1(search_query):
    u = f"http://phongblack.online/search.php?author=phongblack&search={search_query.replace(' ','+')}"
    r = urlquick.get(u, max_age=1000, timeout=20, headers={'user-agent': 'Mozilla/5.0 VietMedia/1.0'})
    return ((k['label'], k['info']['plot'] if k['info']['plot'] else k['label'], k['path'].replace('?action=play&', '?action=browse&').replace('?url=', '?action=browse&url=')) for k in r.json()['items'] if 'fshare' in k['path'])
def get_tkfs2(search_query):
    u = f"https://hdvietnam.xyz/search/{randint(100000, 999999)}/?q={search_query.replace(' ','+')}&o=date&c[title_only]=1"
    r = urlquick.get(u, max_age=1000, timeout=20)
    soup = BeautifulSoup(r.text, 'html.parser')
    return ((k.select_one('h3.title a').get_text(strip=True), k.select_one('blockquote').get_text(strip=True), f"https://www.hdvietnam.xyz/{k.select_one('h3.title a')['href']}") for k in soup.select('div.listBlock.main') if 'titleText' in r.text)
def get_tkfs3(search_query):
    u = f"https://thuvienhd.xyz/?s={search_query.replace(' ','+')}"
    r = urlquick.get(u, max_age=1000, timeout=20)
    soup = BeautifulSoup(r.text, 'html.parser')
    return ((k.select_one('div.title a').get_text(strip=True), k.select_one('div.image img')['src'], k.select_one('div.contenido p').get_text(strip=True), k.select_one('a')['href']) for k in soup.select('div.result-item article'))
def get_tkfs4(search_query):
    u = f"https://thuviencine.com/?s={search_query.replace(' ','+')}"
    r = urlquick.get(u, max_age=1000, timeout=20)
    soup = BeautifulSoup(r.text, 'html.parser')
    return ((k['title'], k.select_one('img.lazy')['data-src'], k.select_one('p.movie-description').get_text(strip=True), k['href']) for k in soup.select('div.item.normal a'))
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('[COLOR yellow]TÌM KIẾM[/COLOR]', addon_icon, 'Tìm phim', get_url(mode = 'search'))
        addDir('Lịch sử', addon_icon, 'Lịch sử tìm kiếm', get_url(mode = 'history'))
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        try:
            query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
            if query:
                save_last_search((query, f'plugin://plugin.video.timfshare/?mode=lastseach&query={query}'))
                query = quote_plus(query)
                with ThreadPoolExecutor(4) as ex:
                    f1 = ex.submit(get_tkfs1, query)
                    f2 = ex.submit(get_tkfs2, query)
                    f3 = ex.submit(get_tkfs3, query)
                    f4 = ex.submit(get_tkfs4, query)
                try:
                    r1 = f1.result()
                    for k1 in r1:
                        addDir(f'[COLOR yellow]timfshare[/COLOR] {k1[0]}', addon_icon, k1[1], k1[2])
                except:
                    pass
                try:
                    r2 = f2.result()
                    for k2 in r2:
                        addDir(f'[COLOR yellow]hdvietnam[/COLOR] {k2[0]}', hdvnimg, k2[1], f'plugin://plugin.video.vietmediaF/?action=browse&url={k2[2]}')
                except:
                    pass
                try:
                    r3 = f3.result()
                    for k3 in r3:
                        addDir(f'[COLOR yellow]thuvienhd[/COLOR] {k3[0]}', k3[1], k3[2], f'plugin://plugin.video.vietmediaF/browse&url={k3[3]}')
                except:
                    pass
                try:
                    r4 = f4.result()
                    for k4 in r4:
                        addDir(f'[COLOR yellow]thuviencine[/COLOR] {k4[0]}', k4[1], k4[2], f'plugin://plugin.video.vietmediaF/browse&url={k4[3]}')
                except:
                    pass
                endOfDirectory(HANDLE)
            else:
                quit()
        except:
            return
    elif params['mode'] == 'lastseach':
        try:
            query = quote_plus(params['query'])
            with ThreadPoolExecutor(4) as ex:
                f1 = ex.submit(get_tkfs1, query)
                f2 = ex.submit(get_tkfs2, query)
                f3 = ex.submit(get_tkfs3, query)
                f4 = ex.submit(get_tkfs4, query)
            try:
                r1 = f1.result()
                for k1 in r1:
                    addDir(f'[COLOR yellow]timfshare[/COLOR] {k1[0]}', addon_icon, k1[1], k1[2])
            except:
                pass
            try:
                r2 = f2.result()
                for k2 in r2:
                    addDir(f'[COLOR yellow]hdvietnam[/COLOR] {k2[0]}', hdvnimg, k2[1], f'plugin://plugin.video.vietmediaF/?action=browse&url={k2[2]}')
            except:
                pass
            try:
                r3 = f3.result()
                for k3 in r3:
                    addDir(f'[COLOR yellow]thuvienhd[/COLOR] {k3[0]}', k3[1], k3[2], f'plugin://plugin.video.vietmediaF/browse&url={k3[3]}')
            except:
                pass
            try:
                r4 = f4.result()
                for k4 in r4:
                    addDir(f'[COLOR yellow]thuviencine[/COLOR] {k4[0]}', k4[1], k4[2], f'plugin://plugin.video.vietmediaF/browse&url={k4[3]}')
            except:
                pass
            endOfDirectory(HANDLE)
        except:
            return
    elif params['mode'] =='history':
        b = get_last_search()
        if b:
            for m in b:
                addDir(m, addon_icon, m, b[m])
            addDir('Xóa lịch sử', addon_icon, 'Xóa lịch sử tìm kiếm', get_url(mode = 'clear'))
        endOfDirectory(HANDLE)
    elif params['mode'] =='clear':
        write_file('search.json', '')
        xbmc.executebuiltin('Notification("%s", "%s", "%d", "%s")' % (f"[COLOR darkgoldenrod]{addon_name}[/COLOR]", "Đã xóa lịch sử tìm kiếm", 2000, addon_icon))
        xbmc.executebuiltin("Container.Refresh")
        endOfDirectory(HANDLE, succeeded=False)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ!')
if __name__ == '__main__':
    router(sys.argv[2][1:])