from urllib.parse import urlencode, parse_qsl, unquote, quote_plus, urlparse
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
from datetime import datetime
import re, sys, requests, xbmcgui, json, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
idsource = Addon().getSetting('idsource')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'

def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    kwargs = {key: json.dumps(value) if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
    
def getlink(url, ref):
    r = requests.get(url, timeout=20, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r

def url_to_text(url):
    last_part = url.split('/')[-1]
    return re.sub(r'\W+', ' ', last_part).strip().upper()

def check_string(m, target):
    if not m:
        return False
    m = re.sub(r"\s+", "", m).lower()
    target = re.sub(r"\s+", "", target).lower()
    return m in target

def fu(url):
    return requests.get(url, headers={'user-agent': UA, 'referer': url.encode('utf-8')}, allow_redirects=True).url

def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'

def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)

def main():    
    url = 'https://vtvgo.4share.me/livetv'
    resp = getlink(url, url).json()['groups']    
    for k in resp:
        if k.get('channels'):
            for j in k['channels']:
                name = j['name']
                image = j['image']['url'] if j.get('image') else ICON 
                urlk= j['remote_data']['url'] if j.get('remote_data') else None
                if urlk:
                    addDir(name, image, name, 'list_vtvGo', link = urlk, is_folder=False)      
    endOfDirectory(HANDLE)   

def list_vtvGo(link):    
    link = getlink(link, link).json()["sources"][0]["contents"][0]["streams"][0]["stream_links"][0]["url"]    
    if link:
        play_vtvGo(link)         
            
def play_vtvGo(link, ref=None):
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    if ref:
        hdr += f'&Referer={ref}/'
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = f'{linkplay}|{hdr}'
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
                                 
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {        
        'list_vtvGo': partial(list_vtvGo, params.get('link')),       
        'play_vtvGo': partial(play_vtvGo, params.get('link')),        
    }
    action_map.get(params.get('mode'), main)()
    
try:
    router(sys.argv[2][1:])
except:
    pass