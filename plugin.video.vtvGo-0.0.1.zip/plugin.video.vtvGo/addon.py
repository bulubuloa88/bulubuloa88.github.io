import sys, os, re, json, requests
from urllib.parse import urlencode, parse_qsl, unquote
from functools import partial
import xbmcgui
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath

addon_url = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
addon_name = Addon().getAddonInfo("name")
addon_id = Addon().getAddonInfo("id")
ICON = Addon().getAddonInfo("icon")
addon_data_dir = os.path.join(translatePath("special://userdata/addon_data"), addon_id)
UA = "Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0"

CACHE_FILE = os.path.join(addon_data_dir, "channels_cache.json")


def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    kwargs = {
        key: json.dumps(value) if isinstance(value, list) else value
        for key, value in kwargs.items()
    }
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({"icon": img, "thumb": img, "poster": img, "fanart": img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, "videos")
    if not is_folder:
        list_item.setProperty("IsPlayable", "true")
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)


def getlink(url, ref):
    r = requests.get(url, timeout=20, headers={"user-agent": UA, "referer": ref})
    r.encoding = "utf-8"
    return r


def parse_m3u(data):
    lines = data.splitlines()
    channels = {}
    for i in range(len(lines)):
        line = lines[i].strip()
        if line.startswith("#EXTINF"):
            group_match = re.search(r'group-title="([^"]+)"', line)
            logo_match = re.search(r'tvg-logo="([^"]+)"', line)
            name_match = line.split(",")[-1]

            group_title = group_match.group(1) if group_match else "Unknown"
            logo_url = logo_match.group(1) if logo_match else None
            stream_url = lines[i + 1].strip() if i + 1 < len(lines) else None

            if group_title not in channels:
                channels[group_title] = []
            channels[group_title].append(
                {"name": name_match, "logo_url": logo_url, "stream_url": stream_url}
            )
    return channels


def clear_cache():
    try:
        if os.path.exists(CACHE_FILE):
            os.remove(CACHE_FILE)
            xbmcgui.Dialog().notification(addon_name, "Đã xóa cache", ICON, 3000)
    except Exception as e:
        xbmcgui.Dialog().notification(addon_name, f"Lỗi xóa cache: {e}", ICON, 3000)
    main()


def load_channels():
    refresh_cache = Addon().getSettingBool("refresh_cache")

    if os.path.exists(CACHE_FILE) and not refresh_cache:
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    url = "https://xem.hoiquan.click"
    data = getlink(url, url).text
    channels = parse_m3u(data)

    os.makedirs(addon_data_dir, exist_ok=True)
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(channels, f, ensure_ascii=False, indent=2)

    return channels


def main():
    channels = load_channels()
    for group_title in list(channels.keys()):
        addDir(
            group_title,
            ICON,
            group_title,
            "index_vtvGo",
            group_title=group_title,
        )
    # thêm menu Clear Cache
    addDir("Xóa Cache", ICON, "Xóa dữ liệu cache", "clear_cache", is_folder=False)
    endOfDirectory(HANDLE)


def index_vtvGo(group_title):
    channels = load_channels()
    group_channels = channels.get(group_title, [])
    for channel in group_channels:
        name = channel.get("name", "Unknown")
        image = channel.get("logo_url") or ICON
        urlk = channel.get("stream_url")
        if urlk:
            addDir(name, image, name, "play_vtvGo", link=urlk, is_folder=False)
    endOfDirectory(HANDLE)


def play_vtvGo(link, ref=None):
    hdr = f"verifypeer=false&User-Agent={unquote(UA)}"
    linkplay = re.sub(r"\s+", "%20", link.strip(), flags=re.UNICODE)
    if ref:
        hdr += f"&Referer={ref}/"
    play_item = xbmcgui.ListItem(offscreen=True)
    if "m3u8" in linkplay:
        play_item.setProperty("inputstream", "inputstream.adaptive")
        play_item.setProperty("inputstream.adaptive.stream_headers", hdr)
        play_item.setProperty("inputstream.adaptive.manifest_headers", hdr)
    else:
        linkplay = f"{linkplay}|{hdr}"
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        "index_vtvGo": partial(index_vtvGo, params.get("group_title")),
        "play_vtvGo": partial(play_vtvGo, params.get("link")),
        "clear_cache": clear_cache,
    }
    action = params.get("mode")
    if action in action_map:
        action_map[action]()
    else:
        main()


if __name__ == "__main__":
    if len(sys.argv) >= 3:
        router(sys.argv[2][1:])
    else:
        main()
